# pymodeltime

## Installation



```
!pip install git+https://github.com/Shafi2016/pymodeltime.git
```
